package dam2.TFG.Film24;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Film241ApplicationTests {

	@Test
	void contextLoads() {
	}

}
