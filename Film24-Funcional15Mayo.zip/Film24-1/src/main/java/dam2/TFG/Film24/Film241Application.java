package dam2.TFG.Film24;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Film241Application {
	public static void main(String[] args) {
		SpringApplication.run(Film241Application.class, args);
	}
}
